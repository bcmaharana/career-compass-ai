"""Integration tests for the identity module.

Exercises the full stack — API routers, application services,
repositories, RLS policies — against a real Postgres test database
(career_compass_test, see .env.test and conftest.apply_migrations_and_seed).
No mocking of the database layer here; this is deliberately the
"does the whole thing actually work together" tier, complementing the
fast, DB-free unit tests in tests/unit/.

Each test uses a fresh, randomly-suffixed subdomain rather than
truncating tables between tests — simpler, and avoids interfering with
parallel test runs.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest
from httpx import AsyncClient

from app.adapters.db.base import async_session_factory, set_tenant_context
from app.adapters.db.repositories import SqlAlchemyRoleRepository, SqlAlchemyUserRepository
from app.core.security import hash_password
from app.domain.identity.entities import User, UserRoleAssignment

pytestmark = [pytest.mark.integration, pytest.mark.usefixtures("apply_migrations_and_seed")]


def _unique_subdomain() -> str:
    return f"test-{uuid.uuid4().hex[:12]}"


async def _register_tenant(client: AsyncClient, subdomain: str) -> dict:
    response = await client.post(
        "/api/v1/identity/tenants",
        json={
            "tenant_name": f"{subdomain} Inc",
            "subdomain": subdomain,
            "organization_name": f"{subdomain} HQ",
            "admin_email": f"admin@{subdomain}.com",
            "admin_password": "correct-horse-battery",
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


async def _login(client: AsyncClient, subdomain: str, email: str, password: str) -> dict:
    response = await client.post(
        "/api/v1/identity/login",
        json={"subdomain": subdomain, "email": email, "password": password},
    )
    assert response.status_code == 200, response.text
    return response.json()


class TestTenantRegistration:
    async def test_register_tenant_creates_tenant_org_and_admin_user(
        self, client: AsyncClient
    ) -> None:
        subdomain = _unique_subdomain()

        result = await _register_tenant(client, subdomain)

        assert result["tenant_id"]
        assert result["organization_id"]
        assert result["admin_user_id"]
        assert result["admin_email"] == f"admin@{subdomain}.com"

    async def test_duplicate_subdomain_is_rejected(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        await _register_tenant(client, subdomain)

        response = await client.post(
            "/api/v1/identity/tenants",
            json={
                "tenant_name": "Someone Else",
                "subdomain": subdomain,
                "organization_name": "Someone Else HQ",
                "admin_email": "other@example.com",
                "admin_password": "another-password-1",
            },
        )

        assert response.status_code == 409
        assert response.json()["error"]["code"] == "SUBDOMAIN_TAKEN"


class TestLogin:
    async def test_login_with_correct_credentials_returns_token(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        await _register_tenant(client, subdomain)

        result = await _login(client, subdomain, f"admin@{subdomain}.com", "correct-horse-battery")

        assert result["access_token"]
        assert result["token_type"] == "bearer"
        assert result["email"] == f"admin@{subdomain}.com"
        assert result["roles"] == ["organization_admin"]

    async def test_login_with_wrong_password_returns_401(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        await _register_tenant(client, subdomain)

        response = await client.post(
            "/api/v1/identity/login",
            json={
                "subdomain": subdomain,
                "email": f"admin@{subdomain}.com",
                "password": "wrong-password",
            },
        )

        assert response.status_code == 401
        assert response.json()["error"]["code"] == "INVALID_CREDENTIALS"

    async def test_login_with_unknown_subdomain_returns_401_not_404(
        self, client: AsyncClient
    ) -> None:
        # Deliberately the same error/status as a bad password — see
        # AuthenticateUserService's comment on not revealing whether a
        # subdomain exists.
        response = await client.post(
            "/api/v1/identity/login",
            json={
                "subdomain": "definitely-does-not-exist",
                "email": "nobody@example.com",
                "password": "irrelevant",
            },
        )

        assert response.status_code == 401
        assert response.json()["error"]["code"] == "INVALID_CREDENTIALS"


class TestCurrentUser:
    async def test_me_requires_a_token(self, client: AsyncClient) -> None:
        response = await client.get("/api/v1/identity/me")

        assert response.status_code == 401
        assert response.json()["error"]["code"] == "MISSING_TOKEN"

    async def test_me_rejects_an_invalid_token(self, client: AsyncClient) -> None:
        response = await client.get(
            "/api/v1/identity/me", headers={"Authorization": "Bearer not-a-real-token"}
        )

        assert response.status_code == 401
        assert response.json()["error"]["code"] == "INVALID_TOKEN"

    async def test_me_returns_the_authenticated_user(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        registration = await _register_tenant(client, subdomain)
        login = await _login(client, subdomain, f"admin@{subdomain}.com", "correct-horse-battery")

        response = await client.get(
            "/api/v1/identity/me", headers={"Authorization": f"Bearer {login['access_token']}"}
        )

        assert response.status_code == 200
        body = response.json()
        assert body["user_id"] == registration["admin_user_id"]
        assert body["tenant_id"] == registration["tenant_id"]
        assert body["roles"] == ["organization_admin"]


async def _create_employee_user(tenant_id: str, subdomain: str) -> str:
    """Creates a user with only the 'employee' role, bypassing the API
    (no user-management endpoint exists yet — that's Phase 2+ scope).
    Returns the plaintext password so the test can log in as this user.
    """
    password = "employee-password-1"
    async with async_session_factory() as session:
        await set_tenant_context(session, uuid.UUID(tenant_id))

        users = SqlAlchemyUserRepository(session)
        roles = SqlAlchemyRoleRepository(session)

        user = await users.create(
            User(
                id=uuid.uuid4(),
                tenant_id=uuid.UUID(tenant_id),
                org_id=None,
                email=f"employee@{subdomain}.com",
                hashed_password=hash_password(password),
                status="active",
                mfa_enabled=False,
                created_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
        )

        employee_role = await roles.get_by_name("employee", tenant_id=None)
        assert employee_role is not None, "employee role must be seeded (see conftest fixture)"

        await roles.assign_to_user(
            UserRoleAssignment(
                id=uuid.uuid4(),
                tenant_id=uuid.UUID(tenant_id),
                user_id=user.id,
                role_id=employee_role.id,
                org_id=None,
            )
        )
        await session.commit()

    return password


class TestRoleBasedAccessControl:
    async def test_org_admin_can_read_audit_events(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        await _register_tenant(client, subdomain)
        login = await _login(client, subdomain, f"admin@{subdomain}.com", "correct-horse-battery")

        response = await client.get(
            "/api/v1/identity/audit-events",
            headers={"Authorization": f"Bearer {login['access_token']}"},
        )

        assert response.status_code == 200
        actions = {event["action"] for event in response.json()}
        assert "tenant.created" in actions
        assert "user.created" in actions
        assert "auth.login_success" in actions

    async def test_employee_role_is_denied_audit_events(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        registration = await _register_tenant(client, subdomain)
        password = await _create_employee_user(registration["tenant_id"], subdomain)

        login = await _login(client, subdomain, f"employee@{subdomain}.com", password)

        response = await client.get(
            "/api/v1/identity/audit-events",
            headers={"Authorization": f"Bearer {login['access_token']}"},
        )

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "PERMISSION_DENIED"

    async def test_employee_role_can_still_read_own_profile(self, client: AsyncClient) -> None:
        subdomain = _unique_subdomain()
        registration = await _register_tenant(client, subdomain)
        password = await _create_employee_user(registration["tenant_id"], subdomain)

        login = await _login(client, subdomain, f"employee@{subdomain}.com", password)

        response = await client.get(
            "/api/v1/identity/me", headers={"Authorization": f"Bearer {login['access_token']}"}
        )

        assert response.status_code == 200
        assert response.json()["roles"] == ["employee"]


class TestCrossTenantIsolation:
    async def test_audit_events_never_leak_across_tenants(self, client: AsyncClient) -> None:
        subdomain_a = _unique_subdomain()
        subdomain_b = _unique_subdomain()
        await _register_tenant(client, subdomain_a)
        await _register_tenant(client, subdomain_b)

        login_a = await _login(
            client, subdomain_a, f"admin@{subdomain_a}.com", "correct-horse-battery"
        )
        login_b = await _login(
            client, subdomain_b, f"admin@{subdomain_b}.com", "correct-horse-battery"
        )

        events_a = await client.get(
            "/api/v1/identity/audit-events",
            headers={"Authorization": f"Bearer {login_a['access_token']}"},
        )
        events_b = await client.get(
            "/api/v1/identity/audit-events",
            headers={"Authorization": f"Bearer {login_b['access_token']}"},
        )

        emails_seen_by_a = {e["metadata"].get("email") for e in events_a.json()}
        emails_seen_by_b = {e["metadata"].get("email") for e in events_b.json()}

        assert f"admin@{subdomain_a}.com" in emails_seen_by_a
        assert f"admin@{subdomain_b}.com" not in emails_seen_by_a
        assert f"admin@{subdomain_b}.com" in emails_seen_by_b
        assert f"admin@{subdomain_a}.com" not in emails_seen_by_b

    async def test_current_user_tenant_id_matches_own_tenant_only(
        self, client: AsyncClient
    ) -> None:
        subdomain_a = _unique_subdomain()
        subdomain_b = _unique_subdomain()
        registration_a = await _register_tenant(client, subdomain_a)
        registration_b = await _register_tenant(client, subdomain_b)

        login_a = await _login(
            client, subdomain_a, f"admin@{subdomain_a}.com", "correct-horse-battery"
        )

        response = await client.get(
            "/api/v1/identity/me", headers={"Authorization": f"Bearer {login_a['access_token']}"}
        )

        assert response.json()["tenant_id"] == registration_a["tenant_id"]
        assert response.json()["tenant_id"] != registration_b["tenant_id"]
