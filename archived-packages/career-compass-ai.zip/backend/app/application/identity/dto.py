"""Application-layer DTOs for the Identity module.

Distinct from both the domain entities (app/domain/identity/entities.py)
and the API's Pydantic request/response schemas
(app/api/v1/identity/schemas.py). These carry data across the
application-service boundary without exposing internal domain object
shapes directly to the API layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID


@dataclass(frozen=True, slots=True)
class NewTenantResult:
    tenant_id: UUID
    organization_id: UUID
    admin_user_id: UUID
    admin_email: str


@dataclass(frozen=True, slots=True)
class LoginResult:
    access_token: str
    token_type: str
    user_id: UUID
    tenant_id: UUID
    email: str
    roles: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CurrentUserResult:
    user_id: UUID
    tenant_id: UUID
    org_id: UUID | None
    email: str
    roles: tuple[str, ...]
