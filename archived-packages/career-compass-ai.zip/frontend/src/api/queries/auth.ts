import { apiClient } from "@/api/client";
import type { components } from "@/api/schema.gen";
import { useAuthStore } from "@/stores/auth-store";
import { useMutation, useQuery } from "@tanstack/react-query";

type LoginRequest = components["schemas"]["LoginRequest"];
type LoginResponse = components["schemas"]["LoginResponse"];
type CurrentUserResponse = components["schemas"]["CurrentUserResponse"];

/**
 * Login mutation. On success, stores the token and user summary in the
 * auth store — every other authenticated request then picks up the
 * token automatically via apiClient's Authorization header injection
 * (see api/client.ts).
 */
export function useLogin() {
  const setSession = useAuthStore((state) => state.setSession);

  return useMutation({
    mutationFn: (credentials: LoginRequest) =>
      apiClient.post<LoginResponse>("/api/v1/identity/login", credentials),
    onSuccess: (data) => {
      setSession(data.access_token, {
        id: data.user_id,
        email: data.email,
        tenantId: data.tenant_id,
      });
    },
  });
}

/**
 * Fetches the authenticated user's profile from the backend. Useful for
 * validating a stored token is still good (e.g. on app load) and for
 * displaying the current user's info in the app shell.
 */
export function useCurrentUser() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  return useQuery({
    queryKey: ["current-user"],
    queryFn: () => apiClient.get<CurrentUserResponse>("/api/v1/identity/me"),
    enabled: isAuthenticated,
    retry: false,
  });
}
