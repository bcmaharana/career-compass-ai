import { CareerGoalsSection } from "@/features/career-profile/CareerGoalsSection";
import { CareerHighlightsSection } from "@/features/career-profile/CareerHighlightsSection";
import { CertificationSection } from "@/features/career-profile/CertificationSection";
import { EducationSection } from "@/features/career-profile/EducationSection";
import { ExperienceSection } from "@/features/career-profile/ExperienceSection";
import { KeyAchievementsSection } from "@/features/career-profile/KeyAchievementsSection";
import { PeerEndorsementsSection } from "@/features/career-profile/PeerEndorsementsSection";
import { ProfileHeader } from "@/features/career-profile/ProfileHeader";

/**
 * Section order follows a resume-like flow: identity/summary first,
 * then experience-adjacent proof points (highlights, then the full
 * experience history), education and certifications, then forward
 * -looking (goals) and third-party validation (recommendations) last.
 * "Technical Skills" is deliberately not here — see Phase 3, Skill
 * Intelligence, which owns a real skill taxonomy rather than a plain
 * text list on this page.
 */
export function CareerProfilePage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Career Profile</h1>
        <p className="text-sm text-muted-foreground">
          Your living career profile — experience, education, certifications, and goals.
        </p>
      </div>

      <div className="grid max-w-3xl gap-6">
        <ProfileHeader />
        <CareerHighlightsSection />
        <ExperienceSection />
        <EducationSection />
        <CertificationSection />
        <KeyAchievementsSection />
        <CareerGoalsSection />
        <PeerEndorsementsSection />
      </div>
    </div>
  );
}
