import { ApiError } from "@/api/client";
import { useLogin } from "@/api/queries/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Compass } from "lucide-react";
import { type FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";

/**
 * Sign-in screen, wired to the real Phase 1 identity service
 * (POST /api/v1/identity/login). Subdomain is a separate field rather
 * than folded into email because tenants are resolved by subdomain, not
 * inferred from the email's domain — see
 * app/application/identity/authenticate_user.py on the backend for why.
 */
export function LoginPage() {
  const navigate = useNavigate();
  const login = useLogin();

  const [subdomain, setSubdomain] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    login.mutate(
      { subdomain, email, password },
      { onSuccess: () => navigate("/", { replace: true }) },
    );
  }

  const errorMessage =
    login.error instanceof ApiError
      ? login.error.message
      : login.isError
        ? "Something went wrong signing in. Please try again."
        : null;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="items-center text-center">
          <Compass className="mb-2 h-8 w-8 text-accent" strokeWidth={2} />
          <CardTitle>Sign in to Career Compass</CardTitle>
          <CardDescription>Continuous career intelligence for you and your team.</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="subdomain">Organization</Label>
              <Input
                id="subdomain"
                type="text"
                placeholder="acme"
                autoComplete="organization"
                required
                value={subdomain}
                onChange={(e) => setSubdomain(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="email">Work email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {errorMessage && (
              <p role="alert" className="text-sm text-destructive">
                {errorMessage}
              </p>
            )}

            <Button type="submit" className="mt-2 w-full" disabled={login.isPending}>
              {login.isPending ? "Signing in..." : "Sign in"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
