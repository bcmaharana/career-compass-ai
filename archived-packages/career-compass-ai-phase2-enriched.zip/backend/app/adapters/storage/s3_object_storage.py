"""S3-compatible object storage adapter.

Works against MinIO locally (see infra/docker-compose.yml) and any real
S3-compatible service in production — same client, just a different
`endpoint_url`/credentials in configuration. Implements
ObjectStorageRepository (app/domain/career_profile/storage.py).

boto3's client is synchronous; every call here runs it via
`asyncio.to_thread` so it doesn't block the event loop, rather than
pulling in aioboto3 as an extra dependency for what's currently a single
small upload path.
"""

from __future__ import annotations

import asyncio

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from app.core.config import Settings
from app.core.exceptions import CareerCompassError


class ObjectStorageError(CareerCompassError):
    code = "OBJECT_STORAGE_ERROR"


class S3ObjectStorageRepository:
    def __init__(self, settings: Settings) -> None:
        self._bucket = settings.object_storage_bucket
        self._public_base_url = settings.object_storage_endpoint.rstrip("/")
        self._client = boto3.client(
            "s3",
            endpoint_url=settings.object_storage_endpoint,
            aws_access_key_id=settings.object_storage_access_key,
            aws_secret_access_key=settings.object_storage_secret_key,
        )

    async def upload(self, *, key: str, content: bytes, content_type: str) -> str:
        try:
            await asyncio.to_thread(
                self._client.put_object,
                Bucket=self._bucket,
                Key=key,
                Body=content,
                ContentType=content_type,
            )
        except (ClientError, BotoCoreError) as exc:
            raise ObjectStorageError(f"Failed to upload object '{key}'.") from exc

        return f"{self._public_base_url}/{self._bucket}/{key}"

    async def delete(self, *, key: str) -> None:
        try:
            await asyncio.to_thread(self._client.delete_object, Bucket=self._bucket, Key=key)
        except (ClientError, BotoCoreError) as exc:
            # Deletion is idempotent from the caller's perspective (see
            # ObjectStorageRepository.delete's docstring) — a "not found"
            # from the provider isn't a real error here, but a transport
            # or auth failure still should surface.
            raise ObjectStorageError(f"Failed to delete object '{key}'.") from exc
