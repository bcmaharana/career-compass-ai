import { cn } from "@/lib/utils";
import { useAuthStore } from "@/stores/auth-store";
import { Compass, Gauge, LineChart, LogOut, Sparkles, UserCircle } from "lucide-react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: Gauge, end: true },
  { to: "/profile", label: "Career Profile", icon: UserCircle },
  { to: "/skills", label: "Skill Intelligence", icon: LineChart },
  { to: "/coach", label: "AI Career Coach", icon: Sparkles },
];

/**
 * Application shell: fixed-height sidebar + independently scrollable
 * content area.
 *
 * The sidebar is pinned to the viewport height (`h-screen sticky top-0`)
 * rather than growing with page content — previously it stretched to
 * match whatever height the main content area reached, which pushed the
 * user-info/sign-out footer below the fold on any page taller than one
 * screen. Now the nav list scrolls independently (`overflow-y-auto`) if
 * it ever has enough items to need it, while the footer stays anchored
 * to the bottom of the viewport at all times via `mt-auto` inside a
 * fixed-height flex column.
 */
export function AppShell() {
  const navigate = useNavigate();
  const user = useAuthStore((state) => state.user);
  const clearSession = useAuthStore((state) => state.clearSession);

  function handleLogout() {
    clearSession();
    navigate("/login", { replace: true });
  }

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="sticky top-0 flex h-screen w-64 shrink-0 flex-col bg-primary text-primary-foreground">
        <div className="flex items-center gap-2 px-6 py-5">
          <Compass className="h-6 w-6 text-accent" strokeWidth={2} />
          <span className="font-display text-lg font-semibold tracking-tight">
            Career Compass
          </span>
        </div>

        <nav className="mt-4 flex flex-1 flex-col gap-1 overflow-y-auto px-3">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 rounded-md border-l-2 border-transparent px-3 py-2 text-sm",
                  "text-primary-foreground/80 transition-colors hover:bg-white/5 hover:text-primary-foreground",
                  isActive && "border-accent bg-white/5 text-primary-foreground",
                )
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto flex shrink-0 flex-col gap-2 border-t border-white/10 px-3 py-4">
          {user && (
            <span className="truncate px-3 text-xs text-primary-foreground/60">{user.email}</span>
          )}
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 rounded-md px-3 py-2 text-sm text-primary-foreground/80 transition-colors hover:bg-white/5 hover:text-primary-foreground"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="container py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
