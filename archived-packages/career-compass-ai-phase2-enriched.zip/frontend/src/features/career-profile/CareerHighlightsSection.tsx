import {
  useAddCareerHighlight,
  useCareerHighlights,
  useDeleteCareerHighlight,
  useUpdateCareerHighlight,
} from "@/api/queries/career-profile";
import type { components } from "@/api/schema.gen";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";

type CareerHighlight = components["schemas"]["CareerHighlightResponse"];

interface FormState {
  title: string;
  description: string;
  occurred_on: string;
}

const EMPTY_FORM: FormState = { title: "", description: "", occurred_on: "" };

function toFormState(highlight: CareerHighlight): FormState {
  return {
    title: highlight.title,
    description: highlight.description ?? "",
    occurred_on: highlight.occurred_on ?? "",
  };
}

export function CareerHighlightsSection() {
  const { data: highlights, isLoading } = useCareerHighlights();
  const addHighlight = useAddCareerHighlight();
  const updateHighlight = useUpdateCareerHighlight();
  const deleteHighlight = useDeleteCareerHighlight();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  function openAddDialog() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEditDialog(highlight: CareerHighlight) {
    setEditingId(highlight.id);
    setForm(toFormState(highlight));
    setDialogOpen(true);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = {
      title: form.title,
      description: form.description || null,
      occurred_on: form.occurred_on || null,
    };
    const mutation = editingId
      ? updateHighlight.mutateAsync({ id: editingId, body })
      : addHighlight.mutateAsync(body);
    mutation.then(() => setDialogOpen(false));
  }

  const isSaving = addHighlight.isPending || updateHighlight.isPending;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Career Highlights</CardTitle>
        <Button variant="outline" size="sm" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {highlights?.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No highlights added yet — standout moments from your career, separate from your full
            work history.
          </p>
        )}
        {highlights?.map((highlight) => (
          <div
            key={highlight.id}
            className="flex items-start justify-between gap-4 rounded-md border border-border p-4"
          >
            <div>
              <p className="font-medium">{highlight.title}</p>
              {highlight.occurred_on && (
                <p className="text-xs text-muted-foreground">{highlight.occurred_on}</p>
              )}
              {highlight.description && <p className="mt-1 text-sm">{highlight.description}</p>}
            </div>
            <div className="flex shrink-0 gap-1">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(highlight)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteHighlight.mutate(highlight.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title={editingId ? "Edit highlight" : "Add highlight"}
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="highlight-title">Title</Label>
            <Input
              id="highlight-title"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="highlight-date">Date</Label>
            <Input
              id="highlight-date"
              type="date"
              value={form.occurred_on}
              onChange={(e) => setForm({ ...form, occurred_on: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="highlight-description">Description</Label>
            <Textarea
              id="highlight-description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
            />
          </div>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? "Saving..." : editingId ? "Save changes" : "Add highlight"}
          </Button>
        </form>
      </Dialog>
    </Card>
  );
}
