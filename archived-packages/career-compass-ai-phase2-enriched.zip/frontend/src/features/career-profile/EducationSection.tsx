import {
  useAddEducation,
  useDeleteEducation,
  useEducations,
  useUpdateEducation,
} from "@/api/queries/career-profile";
import type { components } from "@/api/schema.gen";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";

type Education = components["schemas"]["EducationResponse"];

interface FormState {
  institution: string;
  degree: string;
  field_of_study: string;
  start_date: string;
  end_date: string;
  description: string;
}

const EMPTY_FORM: FormState = {
  institution: "",
  degree: "",
  field_of_study: "",
  start_date: "",
  end_date: "",
  description: "",
};

function toFormState(education: Education): FormState {
  return {
    institution: education.institution,
    degree: education.degree ?? "",
    field_of_study: education.field_of_study ?? "",
    start_date: education.start_date ?? "",
    end_date: education.end_date ?? "",
    description: education.description ?? "",
  };
}

export function EducationSection() {
  const { data: educations, isLoading } = useEducations();
  const addEducation = useAddEducation();
  const updateEducation = useUpdateEducation();
  const deleteEducation = useDeleteEducation();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  function openAddDialog() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEditDialog(education: Education) {
    setEditingId(education.id);
    setForm(toFormState(education));
    setDialogOpen(true);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = {
      institution: form.institution,
      degree: form.degree || null,
      field_of_study: form.field_of_study || null,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      description: form.description || null,
    };

    const mutation = editingId
      ? updateEducation.mutateAsync({ id: editingId, body })
      : addEducation.mutateAsync(body);

    mutation.then(() => setDialogOpen(false));
  }

  const isSaving = addEducation.isPending || updateEducation.isPending;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Education</CardTitle>
        <Button variant="outline" size="sm" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {educations?.length === 0 && (
          <p className="text-sm text-muted-foreground">No education added yet.</p>
        )}
        {educations?.map((education) => (
          <div
            key={education.id}
            className="flex items-start justify-between gap-4 rounded-md border border-border p-4"
          >
            <div>
              <p className="font-medium">{education.institution}</p>
              <p className="text-sm text-muted-foreground">
                {[education.degree, education.field_of_study].filter(Boolean).join(", ")}
              </p>
              {(education.start_date || education.end_date) && (
                <p className="text-xs text-muted-foreground">
                  {education.start_date ?? "?"} – {education.end_date ?? "Present"}
                </p>
              )}
            </div>
            <div className="flex shrink-0 gap-1">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(education)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteEducation.mutate(education.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title={editingId ? "Edit education" : "Add education"}
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edu-institution">Institution</Label>
            <Input
              id="edu-institution"
              required
              value={form.institution}
              onChange={(e) => setForm({ ...form, institution: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edu-degree">Degree</Label>
            <Input
              id="edu-degree"
              value={form.degree}
              onChange={(e) => setForm({ ...form, degree: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edu-field">Field of study</Label>
            <Input
              id="edu-field"
              value={form.field_of_study}
              onChange={(e) => setForm({ ...form, field_of_study: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="edu-start">Start date</Label>
              <Input
                id="edu-start"
                type="date"
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="edu-end">End date</Label>
              <Input
                id="edu-end"
                type="date"
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
              />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edu-description">Description</Label>
            <Textarea
              id="edu-description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
            />
          </div>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? "Saving..." : editingId ? "Save changes" : "Add education"}
          </Button>
        </form>
      </Dialog>
    </Card>
  );
}
