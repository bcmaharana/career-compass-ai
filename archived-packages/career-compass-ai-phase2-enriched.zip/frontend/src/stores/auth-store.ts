import { create } from "zustand";

/**
 * Authentication placeholder store.
 *
 * Holds client-side session state only (access token, current user
 * summary). Deliberately a thin Zustand store, not a data-fetching layer
 * — actual login/logout calls belong in api/queries/auth.ts once Phase 1
 * ships the backend's InternalJWTProvider endpoints. Isolating token
 * storage here (rather than scattering it across feature modules) is
 * what lets a future SSO/OIDC switch touch one file instead of every
 * feature (see docs/adr/ADR-003-authentication-strategy.md).
 *
 * Token is kept in memory only, not localStorage — refresh-on-reload will
 * be handled by a silent-refresh call against the backend once Phase 1's
 * refresh-token endpoint exists, not by persisting the access token
 * client-side.
 */

export interface AuthenticatedUser {
  id: string;
  email: string;
  tenantId: string;
}

interface AuthState {
  accessToken: string | null;
  user: AuthenticatedUser | null;
  isAuthenticated: boolean;
  setSession: (accessToken: string, user: AuthenticatedUser) => void;
  clearSession: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  accessToken: null,
  user: null,
  isAuthenticated: false,
  setSession: (accessToken, user) => set({ accessToken, user, isAuthenticated: true }),
  clearSession: () => set({ accessToken: null, user: null, isAuthenticated: false }),
}));
