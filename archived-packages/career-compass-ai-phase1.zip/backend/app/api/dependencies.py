"""Shared FastAPI dependencies: database sessions, current identity
resolution, and RBAC enforcement.

This module is the seam between "framework" and "everything else" — it's
where concrete adapters (SQLAlchemy sessions, the InternalJWTProvider)
get wired into application services via Depends(), so application
services themselves only ever see interfaces (see
docs/architecture/backend-architecture.md, "Dependency Injection").
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Awaitable, Callable
from uuid import UUID

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.db.base import async_session_factory, set_tenant_context
from app.adapters.db.repositories import (
    SqlAlchemyAuditEventRepository,
    SqlAlchemyFeatureFlagRepository,
    SqlAlchemyOrganizationRepository,
    SqlAlchemyRoleRepository,
    SqlAlchemyTenantContextBinder,
    SqlAlchemyTenantRepository,
    SqlAlchemyUserRepository,
)
from app.adapters.identity_providers.internal_jwt import InternalJWTProvider, verify_access_token
from app.application.identity.audit_service import AuditService
from app.application.identity.authenticate_user import AuthenticateUserService
from app.application.identity.get_current_user import GetCurrentUserService
from app.application.identity.list_audit_events import ListAuditEventsService
from app.application.identity.list_feature_flags import ListFeatureFlagsService
from app.application.identity.register_tenant import RegisterTenantService
from app.core.exceptions import ForbiddenError, UnauthorizedError
from app.core.identity_provider_interface import IdentityClaims
from app.domain.identity.authorization import has_permission
from app.domain.identity.entities import Role

_bearer_scheme = HTTPBearer(auto_error=False)


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Plain session, no tenant context — for pre-auth flows
    (registration, login) that bind tenant context themselves once they
    know which tenant is in play.
    """
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_current_identity(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
) -> IdentityClaims:
    """Resolve and verify the caller's identity from the Authorization
    header. Every protected route depends on this (directly or via
    require_permission) rather than decoding tokens itself.
    """
    if credentials is None:
        raise UnauthorizedError("Missing bearer token.", code="MISSING_TOKEN")

    return verify_access_token(credentials.credentials)


async def get_tenant_scoped_session(
    identity: IdentityClaims = Depends(get_current_identity),
) -> AsyncGenerator[AsyncSession, None]:
    """A session with RLS tenant context already bound from the caller's
    verified JWT. Every protected route that touches tenant-owned data
    should depend on this instead of get_db_session.
    """
    async with async_session_factory() as session:
        try:
            await set_tenant_context(session, UUID(identity.tenant_id))
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


def get_role_repository(
    session: AsyncSession = Depends(get_tenant_scoped_session),
) -> SqlAlchemyRoleRepository:
    return SqlAlchemyRoleRepository(session)


async def get_current_user_roles(
    identity: IdentityClaims = Depends(get_current_identity),
    roles: SqlAlchemyRoleRepository = Depends(get_role_repository),
) -> list[Role]:
    return await roles.list_for_user(UUID(identity.tenant_id), UUID(identity.user_id))


def require_permission(permission_code: str) -> Callable[..., Awaitable[IdentityClaims]]:
    """Dependency factory: returns a FastAPI dependency that raises
    ForbiddenError unless the current user holds `permission_code` via
    at least one of their assigned roles.

    Usage: `Depends(require_permission("audit_event:read"))` in a route
    signature. Enforced at the API layer (this module) but the actual
    has_permission check is pure domain logic
    (app/domain/identity/authorization.py) — this function's only job is
    wiring the current user's roles into that check and raising the
    right HTTP-mappable exception if it fails.
    """

    async def dependency(
        identity: IdentityClaims = Depends(get_current_identity),
        roles: list[Role] = Depends(get_current_user_roles),
    ) -> IdentityClaims:
        if not has_permission(roles, permission_code):
            raise ForbiddenError(
                f"Missing required permission: {permission_code}", code="PERMISSION_DENIED"
            )
        return identity

    return dependency


def get_audit_service(session: AsyncSession = Depends(get_tenant_scoped_session)) -> AuditService:
    return AuditService(SqlAlchemyAuditEventRepository(session))


def get_request_ip(request: Request) -> str | None:
    return request.client.host if request.client else None


# --- Pre-auth flow wiring (tenant registration, login) ---
# These use the plain (non-tenant-scoped) session because the tenant
# either doesn't exist yet (registration) or isn't known until the
# request body is parsed (login) — the services themselves call
# TenantContextBinder.bind() once they know which tenant is in play.
# See app/application/identity/register_tenant.py and authenticate_user.py.


def get_tenant_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyTenantRepository:
    return SqlAlchemyTenantRepository(session)


def get_organization_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyOrganizationRepository:
    return SqlAlchemyOrganizationRepository(session)


def get_user_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyUserRepository:
    return SqlAlchemyUserRepository(session)


def get_role_repository_plain(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyRoleRepository:
    return SqlAlchemyRoleRepository(session)


def get_tenant_context_binder(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyTenantContextBinder:
    return SqlAlchemyTenantContextBinder(session)


def get_plain_audit_service(session: AsyncSession = Depends(get_db_session)) -> AuditService:
    return AuditService(SqlAlchemyAuditEventRepository(session))


def get_internal_jwt_provider(
    users: SqlAlchemyUserRepository = Depends(get_user_repository),
    roles: SqlAlchemyRoleRepository = Depends(get_role_repository_plain),
) -> InternalJWTProvider:
    return InternalJWTProvider(users=users, roles=roles)


def get_register_tenant_service(
    tenants: SqlAlchemyTenantRepository = Depends(get_tenant_repository),
    organizations: SqlAlchemyOrganizationRepository = Depends(get_organization_repository),
    users: SqlAlchemyUserRepository = Depends(get_user_repository),
    roles: SqlAlchemyRoleRepository = Depends(get_role_repository_plain),
    tenant_context: SqlAlchemyTenantContextBinder = Depends(get_tenant_context_binder),
    audit: AuditService = Depends(get_plain_audit_service),
) -> RegisterTenantService:
    return RegisterTenantService(
        tenants=tenants,
        organizations=organizations,
        users=users,
        roles=roles,
        tenant_context=tenant_context,
        audit=audit,
    )


def get_authenticate_user_service(
    tenants: SqlAlchemyTenantRepository = Depends(get_tenant_repository),
    tenant_context: SqlAlchemyTenantContextBinder = Depends(get_tenant_context_binder),
    identity_provider: InternalJWTProvider = Depends(get_internal_jwt_provider),
    audit: AuditService = Depends(get_plain_audit_service),
) -> AuthenticateUserService:
    return AuthenticateUserService(
        tenants=tenants,
        tenant_context=tenant_context,
        identity_provider=identity_provider,
        audit=audit,
    )


# --- Post-auth flow wiring (protected routes) ---
# These use get_tenant_scoped_session, which binds RLS context from the
# caller's already-verified JWT (see get_tenant_scoped_session above).


def get_user_repository_scoped(
    session: AsyncSession = Depends(get_tenant_scoped_session),
) -> SqlAlchemyUserRepository:
    return SqlAlchemyUserRepository(session)


def get_feature_flag_repository(
    session: AsyncSession = Depends(get_tenant_scoped_session),
) -> SqlAlchemyFeatureFlagRepository:
    return SqlAlchemyFeatureFlagRepository(session)


def get_current_user_service(
    users: SqlAlchemyUserRepository = Depends(get_user_repository_scoped),
    roles: SqlAlchemyRoleRepository = Depends(get_role_repository),
) -> GetCurrentUserService:
    return GetCurrentUserService(users=users, roles=roles)


def get_audit_event_repository(
    session: AsyncSession = Depends(get_tenant_scoped_session),
) -> SqlAlchemyAuditEventRepository:
    return SqlAlchemyAuditEventRepository(session)


def get_list_audit_events_service(
    audit_events: SqlAlchemyAuditEventRepository = Depends(get_audit_event_repository),
) -> ListAuditEventsService:
    return ListAuditEventsService(audit_events)


def get_list_feature_flags_service(
    feature_flags: SqlAlchemyFeatureFlagRepository = Depends(get_feature_flag_repository),
) -> ListFeatureFlagsService:
    return ListFeatureFlagsService(feature_flags)
