import { useHealthCheck } from "@/api/queries/health";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

/**
 * Placeholder dashboard. Its only job in Phase 0.2 is to prove the whole
 * chain works end to end: React Query hook -> typed API client -> real
 * FastAPI backend -> rendered result. Real dashboard widgets (career
 * readiness score, skill gaps, recommendations, activity timeline) land
 * with their owning feature modules in later phases.
 */
export function DashboardPage() {
  const { data, isLoading, isError, error } = useHealthCheck();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Foundation view — feature widgets arrive with Phases 2 through 8.
        </p>
      </div>

      <Card className="max-w-md">
        <CardHeader>
          <CardTitle>Backend connectivity</CardTitle>
          <CardDescription>Live check against GET /api/v1/health</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading && <p className="text-sm text-muted-foreground">Checking...</p>}
          {isError && (
            <p className="text-sm text-destructive">
              {error instanceof Error ? error.message : "Could not reach the backend."}
            </p>
          )}
          {data && (
            <div className="flex items-center gap-2">
              <Badge variant="accent">{data.status}</Badge>
              <span className="text-sm text-muted-foreground">
                {data.app_name} · {data.app_env}
              </span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
