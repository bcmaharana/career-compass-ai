import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/features/dashboard/DashboardPage";
import { LoginPage } from "@/features/auth/LoginPage";
import { NotFoundPage } from "@/routes/NotFound";
import { createBrowserRouter } from "react-router-dom";

/**
 * Route tree. Feature modules add their own routes here as they land
 * (Phase 2 onward) — this file stays the single source of truth for the
 * app's URL structure, rather than routes being registered ad hoc from
 * inside feature components.
 *
 * /login is outside AppShell (no sidebar). Everything else nests under
 * AppShell. Phase 1 adds a route guard here once real auth exists — for
 * now every route is reachable, since there's nothing to protect yet.
 */
export const router = createBrowserRouter([
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/",
    element: <AppShell />,
    children: [
      { index: true, element: <DashboardPage /> },
      // /skills and /coach nav links exist in AppShell already;
      // their route elements arrive with Phase 3 and Phase 8 respectively.
    ],
  },
  {
    path: "*",
    element: <NotFoundPage />,
  },
]);
