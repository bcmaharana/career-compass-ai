/**
 * Thin fetch wrapper around the backend API.
 *
 * Types come from `src/api/schema.gen.ts`, generated from the backend's
 * OpenAPI schema via `npm run generate:api-types` (requires the backend
 * running locally at http://localhost:8000). Regenerate whenever the
 * backend's API contract changes — never hand-edit schema.gen.ts.
 *
 * This file is intentionally the *only* place that knows about fetch,
 * base URLs, and the backend's error response shape. Feature modules call
 * the typed query/mutation hooks in api/queries/*, never this file
 * directly.
 */

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    request_id: string | null;
  };
}

export class ApiError extends Error {
  readonly code: string;
  readonly requestId: string | null;
  readonly status: number;

  constructor(status: number, body: ApiErrorBody) {
    super(body.error.message);
    this.name = "ApiError";
    this.status = status;
    this.code = body.error.code;
    this.requestId = body.error.request_id;
  }
}

// Empty string -> same-origin requests, proxied to the backend by Vite in
// dev (see vite.config.ts) and by the gateway/load balancer in production.
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
  });

  if (!response.ok) {
    let body: ApiErrorBody;
    try {
      body = (await response.json()) as ApiErrorBody;
    } catch {
      body = { error: { code: "UNKNOWN_ERROR", message: response.statusText, request_id: null } };
    }
    throw new ApiError(response.status, body);
  }

  // 204 No Content and similar have no body to parse.
  if (response.status === 204) {
    return undefined as T;
  }

  return (await response.json()) as T;
}

export const apiClient = {
  get: <T>(path: string) => request<T>(path, { method: "GET" }),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
  delete: <T>(path: string) => request<T>(path, { method: "DELETE" }),
};
