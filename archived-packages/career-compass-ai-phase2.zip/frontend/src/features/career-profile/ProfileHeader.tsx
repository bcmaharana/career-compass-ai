import { useCareerProfile, useUpdateCareerProfile } from "@/api/queries/career-profile";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useEffect, useState } from "react";

/**
 * Editable headline/summary for the current user's career profile.
 * The profile itself is created lazily by the backend on first GET
 * (see app/application/career_profile/career_profile_service.py), so
 * this component never needs to handle a "no profile yet" state.
 */
export function ProfileHeader() {
  const { data: profile, isLoading } = useCareerProfile();
  const updateProfile = useUpdateCareerProfile();

  const [headline, setHeadline] = useState("");
  const [summary, setSummary] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (profile) {
      setHeadline(profile.headline ?? "");
      setSummary(profile.summary ?? "");
    }
  }, [profile]);

  function handleSave() {
    updateProfile.mutate(
      { headline: headline || null, summary: summary || null },
      { onSuccess: () => setIsEditing(false) },
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">Loading profile...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Career Profile</CardTitle>
        {!isEditing && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            Edit
          </Button>
        )}
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {isEditing ? (
          <>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="headline">Headline</Label>
              <Input
                id="headline"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                placeholder="e.g. Senior Product Manager"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="summary">Summary</Label>
              <Textarea
                id="summary"
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="A short overview of your professional background"
                rows={4}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={updateProfile.isPending}>
                {updateProfile.isPending ? "Saving..." : "Save"}
              </Button>
              <Button variant="ghost" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            </div>
          </>
        ) : (
          <>
            <p className="font-medium">
              {profile?.headline || (
                <span className="text-muted-foreground">No headline yet</span>
              )}
            </p>
            <p className="text-sm text-muted-foreground">
              {profile?.summary || "No summary yet — add one to help your AI coach get to know you."}
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
