import { CareerGoalsSection } from "@/features/career-profile/CareerGoalsSection";
import { CertificationSection } from "@/features/career-profile/CertificationSection";
import { EducationSection } from "@/features/career-profile/EducationSection";
import { ExperienceSection } from "@/features/career-profile/ExperienceSection";
import { ProfileHeader } from "@/features/career-profile/ProfileHeader";

export function CareerProfilePage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Career Profile</h1>
        <p className="text-sm text-muted-foreground">
          Your living career profile — experience, education, certifications, and goals.
        </p>
      </div>

      <div className="grid max-w-3xl gap-6">
        <ProfileHeader />
        <ExperienceSection />
        <EducationSection />
        <CertificationSection />
        <CareerGoalsSection />
      </div>
    </div>
  );
}
