"""Career profile application service.

Handles the "one profile per user, created lazily on first access"
pattern, and the versioning behavior from the Phase 0 design package: any
update to tracked fields (headline, summary) snapshots the prior state to
CareerProfileVersion before applying the change, and bumps
current_version.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from uuid import UUID

from app.domain.career_profile.entities import CareerProfile, CareerProfileVersion
from app.domain.career_profile.repositories import (
    CareerProfileRepository,
    CareerProfileVersionRepository,
)


class CareerProfileService:
    def __init__(
        self,
        profiles: CareerProfileRepository,
        versions: CareerProfileVersionRepository,
    ) -> None:
        self._profiles = profiles
        self._versions = versions

    async def get_or_create(self, *, tenant_id: UUID, user_id: UUID) -> CareerProfile:
        existing = await self._profiles.get_by_user_id(tenant_id, user_id)
        if existing is not None:
            return existing

        now = datetime.now(UTC)
        return await self._profiles.create(
            CareerProfile(
                id=uuid.uuid4(),
                tenant_id=tenant_id,
                user_id=user_id,
                current_version=1,
                headline=None,
                summary=None,
                career_readiness_score=None,
                created_at=now,
                updated_at=now,
            )
        )

    async def update(
        self,
        *,
        tenant_id: UUID,
        user_id: UUID,
        headline: str | None,
        summary: str | None,
    ) -> CareerProfile:
        profile = await self.get_or_create(tenant_id=tenant_id, user_id=user_id)

        # Snapshot the prior state before applying the change — an
        # append-only history of what the profile looked like, not what
        # it's changing to.
        await self._versions.create(
            CareerProfileVersion(
                id=uuid.uuid4(),
                career_profile_id=profile.id,
                version_number=profile.current_version,
                snapshot={
                    "headline": profile.headline,
                    "summary": profile.summary,
                    "career_readiness_score": profile.career_readiness_score,
                },
                change_reason="profile_updated",
                created_at=datetime.now(UTC),
            )
        )

        profile.headline = headline
        profile.summary = summary
        profile.current_version += 1
        return await self._profiles.update(profile)
