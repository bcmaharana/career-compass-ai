"""Career Profile domain entities.

Plain dataclasses — no SQLAlchemy, no Pydantic, no FastAPI. Mirrors the
pattern established in app/domain/identity/entities.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from uuid import UUID


@dataclass(slots=True)
class CareerProfile:
    id: UUID
    tenant_id: UUID
    user_id: UUID
    current_version: int
    headline: str | None
    summary: str | None
    career_readiness_score: int | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None


@dataclass(slots=True)
class CareerProfileVersion:
    id: UUID
    career_profile_id: UUID
    version_number: int
    snapshot: dict[str, object]
    change_reason: str | None
    created_at: datetime


@dataclass(slots=True)
class Experience:
    id: UUID
    tenant_id: UUID
    career_profile_id: UUID
    title: str
    company: str
    location: str | None
    start_date: date
    end_date: date | None  # None = current role
    description: str | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None


@dataclass(slots=True)
class Education:
    id: UUID
    tenant_id: UUID
    career_profile_id: UUID
    institution: str
    degree: str | None
    field_of_study: str | None
    start_date: date | None
    end_date: date | None
    description: str | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None


@dataclass(slots=True)
class Certification:
    id: UUID
    tenant_id: UUID
    career_profile_id: UUID
    name: str
    issuing_organization: str
    issue_date: date | None
    expiration_date: date | None
    credential_id: str | None
    credential_url: str | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None


@dataclass(slots=True)
class CareerGoal:
    id: UUID
    tenant_id: UUID
    user_id: UUID
    target_role: str
    target_date: date | None
    status: str
    description: str | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None
