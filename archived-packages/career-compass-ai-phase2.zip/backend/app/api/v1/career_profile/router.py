"""Career Profile API routes.

Thin per backend-architecture.md: parse input, call one application
service, map the result to a response schema. Every route depends on
get_current_identity (or, per convention, get_tenant_scoped_session
transitively via the service dependencies) — self-service data, no extra
RBAC permission required, since a user always manages their own profile.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, status

from app.api.dependencies import (
    get_career_goal_service,
    get_career_profile_service,
    get_certification_service,
    get_current_identity,
    get_education_service,
    get_experience_service,
)
from app.api.v1.career_profile.schemas import (
    CareerGoalRequest,
    CareerGoalResponse,
    CareerGoalUpdateRequest,
    CareerProfileResponse,
    CertificationRequest,
    CertificationResponse,
    EducationRequest,
    EducationResponse,
    ExperienceRequest,
    ExperienceResponse,
    UpdateCareerProfileRequest,
)
from app.application.career_profile.career_goal_service import CareerGoalService
from app.application.career_profile.career_profile_service import CareerProfileService
from app.application.career_profile.certification_service import CertificationService
from app.application.career_profile.education_service import EducationService
from app.application.career_profile.experience_service import ExperienceService
from app.core.identity_provider_interface import IdentityClaims
from app.domain.career_profile.entities import CareerGoal, Certification, Education, Experience

router = APIRouter(tags=["career-profile"])


@router.get("/career-profile", response_model=CareerProfileResponse)
async def get_career_profile(
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerProfileService = Depends(get_career_profile_service),
) -> CareerProfileResponse:
    profile = await service.get_or_create(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id)
    )
    return CareerProfileResponse(
        id=profile.id,
        current_version=profile.current_version,
        headline=profile.headline,
        summary=profile.summary,
        career_readiness_score=profile.career_readiness_score,
    )


@router.patch("/career-profile", response_model=CareerProfileResponse)
async def update_career_profile(
    request: UpdateCareerProfileRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerProfileService = Depends(get_career_profile_service),
) -> CareerProfileResponse:
    profile = await service.update(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        headline=request.headline,
        summary=request.summary,
    )
    return CareerProfileResponse(
        id=profile.id,
        current_version=profile.current_version,
        headline=profile.headline,
        summary=profile.summary,
        career_readiness_score=profile.career_readiness_score,
    )


def _experience_response(experience: Experience) -> ExperienceResponse:
    return ExperienceResponse(
        id=experience.id,
        title=experience.title,
        company=experience.company,
        location=experience.location,
        start_date=experience.start_date,
        end_date=experience.end_date,
        description=experience.description,
    )


@router.get("/career-profile/experiences", response_model=list[ExperienceResponse])
async def list_experiences(
    identity: IdentityClaims = Depends(get_current_identity),
    service: ExperienceService = Depends(get_experience_service),
) -> list[ExperienceResponse]:
    experiences = await service.list_for_current_user(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id)
    )
    return [_experience_response(e) for e in experiences]


@router.post(
    "/career-profile/experiences",
    response_model=ExperienceResponse,
    status_code=status.HTTP_201_CREATED,
)
async def add_experience(
    request: ExperienceRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: ExperienceService = Depends(get_experience_service),
) -> ExperienceResponse:
    experience = await service.add(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        title=request.title,
        company=request.company,
        location=request.location,
        start_date=request.start_date,
        end_date=request.end_date,
        description=request.description,
    )
    return _experience_response(experience)


@router.patch("/career-profile/experiences/{experience_id}", response_model=ExperienceResponse)
async def update_experience(
    experience_id: UUID,
    request: ExperienceRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: ExperienceService = Depends(get_experience_service),
) -> ExperienceResponse:
    experience = await service.update(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        experience_id=experience_id,
        title=request.title,
        company=request.company,
        location=request.location,
        start_date=request.start_date,
        end_date=request.end_date,
        description=request.description,
    )
    return _experience_response(experience)


@router.delete(
    "/career-profile/experiences/{experience_id}", status_code=status.HTTP_204_NO_CONTENT
)
async def delete_experience(
    experience_id: UUID,
    identity: IdentityClaims = Depends(get_current_identity),
    service: ExperienceService = Depends(get_experience_service),
) -> None:
    await service.delete(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        experience_id=experience_id,
    )


def _education_response(education: Education) -> EducationResponse:
    return EducationResponse(
        id=education.id,
        institution=education.institution,
        degree=education.degree,
        field_of_study=education.field_of_study,
        start_date=education.start_date,
        end_date=education.end_date,
        description=education.description,
    )


@router.get("/career-profile/educations", response_model=list[EducationResponse])
async def list_educations(
    identity: IdentityClaims = Depends(get_current_identity),
    service: EducationService = Depends(get_education_service),
) -> list[EducationResponse]:
    educations = await service.list_for_current_user(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id)
    )
    return [_education_response(e) for e in educations]


@router.post(
    "/career-profile/educations",
    response_model=EducationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def add_education(
    request: EducationRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: EducationService = Depends(get_education_service),
) -> EducationResponse:
    education = await service.add(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        institution=request.institution,
        degree=request.degree,
        field_of_study=request.field_of_study,
        start_date=request.start_date,
        end_date=request.end_date,
        description=request.description,
    )
    return _education_response(education)


@router.patch("/career-profile/educations/{education_id}", response_model=EducationResponse)
async def update_education(
    education_id: UUID,
    request: EducationRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: EducationService = Depends(get_education_service),
) -> EducationResponse:
    education = await service.update(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        education_id=education_id,
        institution=request.institution,
        degree=request.degree,
        field_of_study=request.field_of_study,
        start_date=request.start_date,
        end_date=request.end_date,
        description=request.description,
    )
    return _education_response(education)


@router.delete("/career-profile/educations/{education_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_education(
    education_id: UUID,
    identity: IdentityClaims = Depends(get_current_identity),
    service: EducationService = Depends(get_education_service),
) -> None:
    await service.delete(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        education_id=education_id,
    )


def _certification_response(certification: Certification) -> CertificationResponse:
    return CertificationResponse(
        id=certification.id,
        name=certification.name,
        issuing_organization=certification.issuing_organization,
        issue_date=certification.issue_date,
        expiration_date=certification.expiration_date,
        credential_id=certification.credential_id,
        credential_url=certification.credential_url,
    )


@router.get("/career-profile/certifications", response_model=list[CertificationResponse])
async def list_certifications(
    identity: IdentityClaims = Depends(get_current_identity),
    service: CertificationService = Depends(get_certification_service),
) -> list[CertificationResponse]:
    certifications = await service.list_for_current_user(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id)
    )
    return [_certification_response(c) for c in certifications]


@router.post(
    "/career-profile/certifications",
    response_model=CertificationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def add_certification(
    request: CertificationRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CertificationService = Depends(get_certification_service),
) -> CertificationResponse:
    certification = await service.add(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        name=request.name,
        issuing_organization=request.issuing_organization,
        issue_date=request.issue_date,
        expiration_date=request.expiration_date,
        credential_id=request.credential_id,
        credential_url=request.credential_url,
    )
    return _certification_response(certification)


@router.patch(
    "/career-profile/certifications/{certification_id}", response_model=CertificationResponse
)
async def update_certification(
    certification_id: UUID,
    request: CertificationRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CertificationService = Depends(get_certification_service),
) -> CertificationResponse:
    certification = await service.update(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        certification_id=certification_id,
        name=request.name,
        issuing_organization=request.issuing_organization,
        issue_date=request.issue_date,
        expiration_date=request.expiration_date,
        credential_id=request.credential_id,
        credential_url=request.credential_url,
    )
    return _certification_response(certification)


@router.delete(
    "/career-profile/certifications/{certification_id}", status_code=status.HTTP_204_NO_CONTENT
)
async def delete_certification(
    certification_id: UUID,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CertificationService = Depends(get_certification_service),
) -> None:
    await service.delete(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        certification_id=certification_id,
    )


def _goal_response(goal: CareerGoal) -> CareerGoalResponse:
    return CareerGoalResponse(
        id=goal.id,
        target_role=goal.target_role,
        target_date=goal.target_date,
        status=goal.status,
        description=goal.description,
    )


@router.get("/career-goals", response_model=list[CareerGoalResponse])
async def list_career_goals(
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerGoalService = Depends(get_career_goal_service),
) -> list[CareerGoalResponse]:
    goals = await service.list_for_current_user(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id)
    )
    return [_goal_response(g) for g in goals]


@router.post(
    "/career-goals", response_model=CareerGoalResponse, status_code=status.HTTP_201_CREATED
)
async def add_career_goal(
    request: CareerGoalRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerGoalService = Depends(get_career_goal_service),
) -> CareerGoalResponse:
    goal = await service.add(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        target_role=request.target_role,
        target_date=request.target_date,
        description=request.description,
    )
    return _goal_response(goal)


@router.patch("/career-goals/{goal_id}", response_model=CareerGoalResponse)
async def update_career_goal(
    goal_id: UUID,
    request: CareerGoalUpdateRequest,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerGoalService = Depends(get_career_goal_service),
) -> CareerGoalResponse:
    goal = await service.update(
        tenant_id=UUID(identity.tenant_id),
        user_id=UUID(identity.user_id),
        goal_id=goal_id,
        target_role=request.target_role,
        target_date=request.target_date,
        status=request.status,
        description=request.description,
    )
    return _goal_response(goal)


@router.delete("/career-goals/{goal_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_career_goal(
    goal_id: UUID,
    identity: IdentityClaims = Depends(get_current_identity),
    service: CareerGoalService = Depends(get_career_goal_service),
) -> None:
    await service.delete(
        tenant_id=UUID(identity.tenant_id), user_id=UUID(identity.user_id), goal_id=goal_id
    )
