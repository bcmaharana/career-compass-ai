"""Request/response schemas for the career profile API."""

from __future__ import annotations

from datetime import date
from uuid import UUID

from pydantic import BaseModel, Field


class CareerProfileResponse(BaseModel):
    id: UUID
    current_version: int
    headline: str | None
    summary: str | None
    career_readiness_score: int | None


class UpdateCareerProfileRequest(BaseModel):
    headline: str | None = Field(default=None, max_length=255)
    summary: str | None = Field(default=None, max_length=10_000)


class ExperienceRequest(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    company: str = Field(min_length=1, max_length=255)
    location: str | None = Field(default=None, max_length=255)
    start_date: date
    end_date: date | None = None
    description: str | None = Field(default=None, max_length=5_000)


class ExperienceResponse(BaseModel):
    id: UUID
    title: str
    company: str
    location: str | None
    start_date: date
    end_date: date | None
    description: str | None


class EducationRequest(BaseModel):
    institution: str = Field(min_length=1, max_length=255)
    degree: str | None = Field(default=None, max_length=255)
    field_of_study: str | None = Field(default=None, max_length=255)
    start_date: date | None = None
    end_date: date | None = None
    description: str | None = Field(default=None, max_length=5_000)


class EducationResponse(BaseModel):
    id: UUID
    institution: str
    degree: str | None
    field_of_study: str | None
    start_date: date | None
    end_date: date | None
    description: str | None


class CertificationRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    issuing_organization: str = Field(min_length=1, max_length=255)
    issue_date: date | None = None
    expiration_date: date | None = None
    credential_id: str | None = Field(default=None, max_length=255)
    credential_url: str | None = Field(default=None, max_length=2048)


class CertificationResponse(BaseModel):
    id: UUID
    name: str
    issuing_organization: str
    issue_date: date | None
    expiration_date: date | None
    credential_id: str | None
    credential_url: str | None


class CareerGoalRequest(BaseModel):
    target_role: str = Field(min_length=1, max_length=255)
    target_date: date | None = None
    description: str | None = Field(default=None, max_length=2_000)


class CareerGoalUpdateRequest(CareerGoalRequest):
    status: str = Field(pattern="^(active|achieved|abandoned)$")


class CareerGoalResponse(BaseModel):
    id: UUID
    target_role: str
    target_date: date | None
    status: str
    description: str | None
