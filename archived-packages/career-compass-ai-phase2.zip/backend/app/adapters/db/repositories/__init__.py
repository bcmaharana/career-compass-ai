"""Repository implementations, organized one module per domain.

`from app.adapters.db.repositories import SqlAlchemyUserRepository` (and
every other existing import site) keeps working unchanged — this
package re-exports every repository from its domain submodule.
"""

from app.adapters.db.repositories.career_profile import (
    SqlAlchemyCareerGoalRepository,
    SqlAlchemyCareerProfileRepository,
    SqlAlchemyCertificationRepository,
    SqlAlchemyEducationRepository,
    SqlAlchemyExperienceRepository,
)
from app.adapters.db.repositories.identity import (
    SqlAlchemyAuditEventRepository,
    SqlAlchemyFeatureFlagRepository,
    SqlAlchemyOrganizationRepository,
    SqlAlchemyRoleRepository,
    SqlAlchemyTenantContextBinder,
    SqlAlchemyTenantRepository,
    SqlAlchemyUserRepository,
)

__all__ = [
    "SqlAlchemyAuditEventRepository",
    "SqlAlchemyCareerGoalRepository",
    "SqlAlchemyCareerProfileRepository",
    "SqlAlchemyCertificationRepository",
    "SqlAlchemyEducationRepository",
    "SqlAlchemyExperienceRepository",
    "SqlAlchemyFeatureFlagRepository",
    "SqlAlchemyOrganizationRepository",
    "SqlAlchemyRoleRepository",
    "SqlAlchemyTenantContextBinder",
    "SqlAlchemyTenantRepository",
    "SqlAlchemyUserRepository",
]
