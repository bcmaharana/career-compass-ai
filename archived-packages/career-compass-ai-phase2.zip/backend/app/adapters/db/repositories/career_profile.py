"""SQLAlchemy repository implementations for the Career Profile domain.

Mirrors the mapping-function pattern established in
app/adapters/db/repositories/identity.py: each repository translates
between its ORM model and the corresponding domain dataclass, so
application services never see an ORM model directly.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.db.models import (
    CareerGoalModel,
    CareerProfileModel,
    CareerProfileVersionModel,
    CertificationModel,
    EducationModel,
    ExperienceModel,
)
from app.domain.career_profile.entities import (
    CareerGoal,
    CareerProfile,
    CareerProfileVersion,
    Certification,
    Education,
    Experience,
)


def _profile_to_domain(model: CareerProfileModel) -> CareerProfile:
    return CareerProfile(
        id=model.id,
        tenant_id=model.tenant_id,
        user_id=model.user_id,
        current_version=model.current_version,
        headline=model.headline,
        summary=model.summary,
        career_readiness_score=model.career_readiness_score,
        created_at=model.created_at,
        updated_at=model.updated_at,
        deleted_at=model.deleted_at,
    )


def _version_to_domain(model: CareerProfileVersionModel) -> CareerProfileVersion:
    return CareerProfileVersion(
        id=model.id,
        career_profile_id=model.career_profile_id,
        version_number=model.version_number,
        snapshot=model.snapshot,
        change_reason=model.change_reason,
        created_at=model.created_at,
    )


def _experience_to_domain(model: ExperienceModel) -> Experience:
    return Experience(
        id=model.id,
        tenant_id=model.tenant_id,
        career_profile_id=model.career_profile_id,
        title=model.title,
        company=model.company,
        location=model.location,
        start_date=model.start_date,
        end_date=model.end_date,
        description=model.description,
        created_at=model.created_at,
        updated_at=model.updated_at,
        deleted_at=model.deleted_at,
    )


def _education_to_domain(model: EducationModel) -> Education:
    return Education(
        id=model.id,
        tenant_id=model.tenant_id,
        career_profile_id=model.career_profile_id,
        institution=model.institution,
        degree=model.degree,
        field_of_study=model.field_of_study,
        start_date=model.start_date,
        end_date=model.end_date,
        description=model.description,
        created_at=model.created_at,
        updated_at=model.updated_at,
        deleted_at=model.deleted_at,
    )


def _certification_to_domain(model: CertificationModel) -> Certification:
    return Certification(
        id=model.id,
        tenant_id=model.tenant_id,
        career_profile_id=model.career_profile_id,
        name=model.name,
        issuing_organization=model.issuing_organization,
        issue_date=model.issue_date,
        expiration_date=model.expiration_date,
        credential_id=model.credential_id,
        credential_url=model.credential_url,
        created_at=model.created_at,
        updated_at=model.updated_at,
        deleted_at=model.deleted_at,
    )


def _goal_to_domain(model: CareerGoalModel) -> CareerGoal:
    return CareerGoal(
        id=model.id,
        tenant_id=model.tenant_id,
        user_id=model.user_id,
        target_role=model.target_role,
        target_date=model.target_date,
        status=model.status,
        description=model.description,
        created_at=model.created_at,
        updated_at=model.updated_at,
        deleted_at=model.deleted_at,
    )


class SqlAlchemyCareerProfileRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, profile: CareerProfile) -> CareerProfile:
        model = CareerProfileModel(
            id=profile.id,
            tenant_id=profile.tenant_id,
            user_id=profile.user_id,
            current_version=profile.current_version,
            headline=profile.headline,
            summary=profile.summary,
            career_readiness_score=profile.career_readiness_score,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _profile_to_domain(model)

    async def get_by_user_id(self, tenant_id: UUID, user_id: UUID) -> CareerProfile | None:
        result = await self._session.execute(
            select(CareerProfileModel).where(
                CareerProfileModel.tenant_id == tenant_id,
                CareerProfileModel.user_id == user_id,
                CareerProfileModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _profile_to_domain(model) if model else None

    async def get_by_id(self, tenant_id: UUID, profile_id: UUID) -> CareerProfile | None:
        result = await self._session.execute(
            select(CareerProfileModel).where(
                CareerProfileModel.tenant_id == tenant_id,
                CareerProfileModel.id == profile_id,
                CareerProfileModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _profile_to_domain(model) if model else None

    async def update(self, profile: CareerProfile) -> CareerProfile:
        model = await self._session.get(CareerProfileModel, profile.id)
        assert model is not None, "update() called with a profile id that no longer exists"
        model.current_version = profile.current_version
        model.headline = profile.headline
        model.summary = profile.summary
        model.career_readiness_score = profile.career_readiness_score
        await self._session.flush()
        await self._session.refresh(model)
        return _profile_to_domain(model)


class SqlAlchemyCareerProfileVersionRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, version: CareerProfileVersion) -> CareerProfileVersion:
        model = CareerProfileVersionModel(
            id=version.id,
            career_profile_id=version.career_profile_id,
            version_number=version.version_number,
            snapshot=version.snapshot,
            change_reason=version.change_reason,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _version_to_domain(model)

    async def list_for_profile(
        self, career_profile_id: UUID, *, limit: int = 50
    ) -> list[CareerProfileVersion]:
        result = await self._session.execute(
            select(CareerProfileVersionModel)
            .where(CareerProfileVersionModel.career_profile_id == career_profile_id)
            .order_by(CareerProfileVersionModel.version_number.desc())
            .limit(limit)
        )
        return [_version_to_domain(model) for model in result.scalars().all()]


class SqlAlchemyExperienceRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, experience: Experience) -> Experience:
        model = ExperienceModel(
            id=experience.id,
            tenant_id=experience.tenant_id,
            career_profile_id=experience.career_profile_id,
            title=experience.title,
            company=experience.company,
            location=experience.location,
            start_date=experience.start_date,
            end_date=experience.end_date,
            description=experience.description,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _experience_to_domain(model)

    async def get_by_id(self, tenant_id: UUID, experience_id: UUID) -> Experience | None:
        result = await self._session.execute(
            select(ExperienceModel).where(
                ExperienceModel.tenant_id == tenant_id,
                ExperienceModel.id == experience_id,
                ExperienceModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _experience_to_domain(model) if model else None

    async def list_for_profile(self, tenant_id: UUID, career_profile_id: UUID) -> list[Experience]:
        result = await self._session.execute(
            select(ExperienceModel)
            .where(
                ExperienceModel.tenant_id == tenant_id,
                ExperienceModel.career_profile_id == career_profile_id,
                ExperienceModel.deleted_at.is_(None),
            )
            .order_by(ExperienceModel.start_date.desc())
        )
        return [_experience_to_domain(model) for model in result.scalars().all()]

    async def update(self, experience: Experience) -> Experience:
        model = await self._session.get(ExperienceModel, experience.id)
        assert model is not None, "update() called with an experience id that no longer exists"
        model.title = experience.title
        model.company = experience.company
        model.location = experience.location
        model.start_date = experience.start_date
        model.end_date = experience.end_date
        model.description = experience.description
        await self._session.flush()
        await self._session.refresh(model)
        return _experience_to_domain(model)

    async def soft_delete(self, tenant_id: UUID, experience_id: UUID) -> None:
        result = await self._session.execute(
            select(ExperienceModel).where(
                ExperienceModel.tenant_id == tenant_id, ExperienceModel.id == experience_id
            )
        )
        model = result.scalar_one_or_none()
        if model is not None:
            model.deleted_at = datetime.now(UTC)
            await self._session.flush()


class SqlAlchemyEducationRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, education: Education) -> Education:
        model = EducationModel(
            id=education.id,
            tenant_id=education.tenant_id,
            career_profile_id=education.career_profile_id,
            institution=education.institution,
            degree=education.degree,
            field_of_study=education.field_of_study,
            start_date=education.start_date,
            end_date=education.end_date,
            description=education.description,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _education_to_domain(model)

    async def get_by_id(self, tenant_id: UUID, education_id: UUID) -> Education | None:
        result = await self._session.execute(
            select(EducationModel).where(
                EducationModel.tenant_id == tenant_id,
                EducationModel.id == education_id,
                EducationModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _education_to_domain(model) if model else None

    async def list_for_profile(self, tenant_id: UUID, career_profile_id: UUID) -> list[Education]:
        result = await self._session.execute(
            select(EducationModel)
            .where(
                EducationModel.tenant_id == tenant_id,
                EducationModel.career_profile_id == career_profile_id,
                EducationModel.deleted_at.is_(None),
            )
            .order_by(EducationModel.start_date.desc())
        )
        return [_education_to_domain(model) for model in result.scalars().all()]

    async def update(self, education: Education) -> Education:
        model = await self._session.get(EducationModel, education.id)
        assert model is not None, "update() called with an education id that no longer exists"
        model.institution = education.institution
        model.degree = education.degree
        model.field_of_study = education.field_of_study
        model.start_date = education.start_date
        model.end_date = education.end_date
        model.description = education.description
        await self._session.flush()
        await self._session.refresh(model)
        return _education_to_domain(model)

    async def soft_delete(self, tenant_id: UUID, education_id: UUID) -> None:
        result = await self._session.execute(
            select(EducationModel).where(
                EducationModel.tenant_id == tenant_id, EducationModel.id == education_id
            )
        )
        model = result.scalar_one_or_none()
        if model is not None:
            model.deleted_at = datetime.now(UTC)
            await self._session.flush()


class SqlAlchemyCertificationRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, certification: Certification) -> Certification:
        model = CertificationModel(
            id=certification.id,
            tenant_id=certification.tenant_id,
            career_profile_id=certification.career_profile_id,
            name=certification.name,
            issuing_organization=certification.issuing_organization,
            issue_date=certification.issue_date,
            expiration_date=certification.expiration_date,
            credential_id=certification.credential_id,
            credential_url=certification.credential_url,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _certification_to_domain(model)

    async def get_by_id(self, tenant_id: UUID, certification_id: UUID) -> Certification | None:
        result = await self._session.execute(
            select(CertificationModel).where(
                CertificationModel.tenant_id == tenant_id,
                CertificationModel.id == certification_id,
                CertificationModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _certification_to_domain(model) if model else None

    async def list_for_profile(
        self, tenant_id: UUID, career_profile_id: UUID
    ) -> list[Certification]:
        result = await self._session.execute(
            select(CertificationModel)
            .where(
                CertificationModel.tenant_id == tenant_id,
                CertificationModel.career_profile_id == career_profile_id,
                CertificationModel.deleted_at.is_(None),
            )
            .order_by(CertificationModel.issue_date.desc())
        )
        return [_certification_to_domain(model) for model in result.scalars().all()]

    async def update(self, certification: Certification) -> Certification:
        model = await self._session.get(CertificationModel, certification.id)
        assert model is not None, "update() called with a certification id that no longer exists"
        model.name = certification.name
        model.issuing_organization = certification.issuing_organization
        model.issue_date = certification.issue_date
        model.expiration_date = certification.expiration_date
        model.credential_id = certification.credential_id
        model.credential_url = certification.credential_url
        await self._session.flush()
        await self._session.refresh(model)
        return _certification_to_domain(model)

    async def soft_delete(self, tenant_id: UUID, certification_id: UUID) -> None:
        result = await self._session.execute(
            select(CertificationModel).where(
                CertificationModel.tenant_id == tenant_id,
                CertificationModel.id == certification_id,
            )
        )
        model = result.scalar_one_or_none()
        if model is not None:
            model.deleted_at = datetime.now(UTC)
            await self._session.flush()


class SqlAlchemyCareerGoalRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, goal: CareerGoal) -> CareerGoal:
        model = CareerGoalModel(
            id=goal.id,
            tenant_id=goal.tenant_id,
            user_id=goal.user_id,
            target_role=goal.target_role,
            target_date=goal.target_date,
            status=goal.status,
            description=goal.description,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return _goal_to_domain(model)

    async def get_by_id(self, tenant_id: UUID, goal_id: UUID) -> CareerGoal | None:
        result = await self._session.execute(
            select(CareerGoalModel).where(
                CareerGoalModel.tenant_id == tenant_id,
                CareerGoalModel.id == goal_id,
                CareerGoalModel.deleted_at.is_(None),
            )
        )
        model = result.scalar_one_or_none()
        return _goal_to_domain(model) if model else None

    async def list_for_user(self, tenant_id: UUID, user_id: UUID) -> list[CareerGoal]:
        result = await self._session.execute(
            select(CareerGoalModel)
            .where(
                CareerGoalModel.tenant_id == tenant_id,
                CareerGoalModel.user_id == user_id,
                CareerGoalModel.deleted_at.is_(None),
            )
            .order_by(CareerGoalModel.created_at.desc())
        )
        return [_goal_to_domain(model) for model in result.scalars().all()]

    async def update(self, goal: CareerGoal) -> CareerGoal:
        model = await self._session.get(CareerGoalModel, goal.id)
        assert model is not None, "update() called with a goal id that no longer exists"
        model.target_role = goal.target_role
        model.target_date = goal.target_date
        model.status = goal.status
        model.description = goal.description
        await self._session.flush()
        await self._session.refresh(model)
        return _goal_to_domain(model)

    async def soft_delete(self, tenant_id: UUID, goal_id: UUID) -> None:
        result = await self._session.execute(
            select(CareerGoalModel).where(
                CareerGoalModel.tenant_id == tenant_id, CareerGoalModel.id == goal_id
            )
        )
        model = result.scalar_one_or_none()
        if model is not None:
            model.deleted_at = datetime.now(UTC)
            await self._session.flush()
