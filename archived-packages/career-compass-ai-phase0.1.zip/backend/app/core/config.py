"""Application configuration.

All configuration is loaded from environment variables (via a local .env file
in development, real environment variables in deployed environments) and
validated at startup. A missing or malformed required setting fails fast at
process start, rather than surfacing as a runtime error mid-request.

Do not read os.environ directly anywhere else in the codebase — always go
through `get_settings()` so there is a single, typed source of truth.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed application settings, loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- Application ---
    app_name: str = Field(default="career-compass-ai")
    app_env: str = Field(default="local")
    debug: bool = Field(default=False)
    log_level: str = Field(default="INFO")

    # --- Database ---
    database_url: str = Field(
        default="postgresql+psycopg://compass:compass@localhost:5432/career_compass"
    )
    database_pool_size: int = Field(default=5)

    # --- Redis ---
    redis_url: str = Field(default="redis://localhost:6379/0")

    # --- Object storage ---
    object_storage_endpoint: str = Field(default="http://localhost:9000")
    object_storage_access_key: str = Field(default="")
    object_storage_secret_key: str = Field(default="")
    object_storage_bucket: str = Field(default="career-compass-dev")

    # --- Auth ---
    jwt_secret_key: str = Field(default="change-me-in-every-environment")
    jwt_access_token_expire_minutes: int = Field(default=15)
    jwt_algorithm: str = Field(default="HS256")

    # --- AI Platform ---
    anthropic_api_key: str = Field(default="")
    ai_default_model: str = Field(default="claude-sonnet-4-6")

    @property
    def is_local(self) -> bool:
        return self.app_env == "local"

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide Settings singleton.

    Cached so environment variables are read once per process, and so
    FastAPI's Depends(get_settings) reuses the same validated instance
    everywhere it's injected.
    """
    return Settings()
