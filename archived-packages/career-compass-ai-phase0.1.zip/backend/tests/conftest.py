"""Shared pytest fixtures.

Phase 0 provides an httpx AsyncClient fixture wired against the FastAPI
app via ASGITransport (no real network socket, no running server
required) for integration-style tests. Phase 1 adds a fixture that spins
up a test database transaction per test and rolls it back afterward, so
integration tests never leave residue between runs.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest_asyncio.fixture
async def client() -> AsyncGenerator[AsyncClient, None]:
    """An async HTTP client wired directly against the FastAPI app,
    without binding a real network port.
    """
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"
