"""Alembic environment configuration.

The database URL always comes from app.core.config.get_settings(), never
hard-coded here or in alembic.ini, so migrations run against whatever
environment's DATABASE_URL is set — local, CI, staging, or production.

Phase 0 status: empty baseline, no model metadata registered yet (no
domain entities exist). Phase 1 will import the declarative Base and its
models here so `alembic revision --autogenerate` can diff against them.
"""

from __future__ import annotations

from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

from alembic import context
from app.core.config import get_settings

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Phase 1 will set this to the SQLAlchemy declarative Base's metadata,
# e.g.: from app.adapters.db.base import Base; target_metadata = Base.metadata
target_metadata = None

config.set_main_option("sqlalchemy.url", get_settings().database_url)


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
