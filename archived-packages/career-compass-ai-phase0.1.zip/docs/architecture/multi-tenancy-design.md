# Multi-Tenancy Design — Career Compass AI

## Model

Shared database, shared schema, `tenant_id` column on every tenant-owned table, enforced by **PostgreSQL Row-Level Security (RLS)** in addition to application-level filtering (defense in depth — an application bug that forgets a `WHERE tenant_id = ...` clause still cannot leak rows, because the database itself won't return them).

## Tenant Resolution

1. Client authenticates; JWT access token carries a `tenant_id` claim.
2. Request-scoped middleware (`app/api/middleware/request_context.py`) extracts and validates `tenant_id` from the token.
3. Middleware issues `SET LOCAL app.tenant_id = '<uuid>'` on the request's database session/transaction.
4. RLS policies on every tenant-owned table reference `current_setting('app.tenant_id')`, so every query in that transaction is automatically scoped.

## Tier Roadmap

| Tier | Isolation | Target customer | Migration cost |
|---|---|---|---|
| Tier 1 (default, Phase 1 onward) | Shared DB + shared schema + RLS | Most tenants | — |
| Tier 2 | Shared schema, dedicated database | Large enterprise tenants needing performance/compliance isolation | Connection-string swap per tenant; repository code unchanged since it already scopes by `tenant_id` |
| Tier 3 | Dedicated infrastructure (own deployment) | Regulated customers | Same container image, isolated deployment; no application code change |

The repository and domain layers are written against a `tenant_id`-scoped interface regardless of tier, so upgrading a tenant's isolation tier is an infrastructure/ops change, not a code change.

## What's Exempt from Tenant Scoping

Global reference/catalog data is intentionally **not** tenant-owned:

- `Skill` — shared taxonomy
- `PromptVersion`, `ModelVersion` — platform-managed AI governance registries
- Platform-wide `JobOpportunity`/`LearningPath` catalog entries (tenant-specific ones still carry `tenant_id`)

These tables are explicitly marked as exceptions in the schema and migration comments so a future contributor doesn't assume every table needs RLS.

## Phase 0 Status

Phase 0 does not yet create any tenant-owned tables (no entities exist yet). This document defines the pattern that Phase 1's `Tenant`, `Organization`, and `User` migrations will implement, including the RLS policy template, so Phase 1 can move quickly against an agreed design rather than re-litigating it.

## RLS Policy Template (for Phase 1 implementation)

```sql
ALTER TABLE <table_name> ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation_policy ON <table_name>
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

Applied via Alembic migration alongside each tenant-owned table's creation — never applied manually outside of migrations.
