# Frontend Architecture — Career Compass AI

> Frontend scaffolding is delivered in Phase 0.2. This document defines the target shape so backend contracts (OpenAPI schema, error format) are designed compatibly from Phase 0.1 onward.

## Stack

- **React 18 + TypeScript** — component model and type safety
- **Vite** — dev server and build tooling
- **Tailwind CSS** — utility-first styling
- **shadcn/ui** — accessible, unstyled-by-default component primitives customized to the Career Compass design system, rather than a heavy pre-styled component framework
- **React Router** — routing
- **TanStack Query** — server state (caching, refetching, mutations) — matched to the backend's REST/OpenAPI shape
- **Zustand** — local/client UI state (e.g., sidebar collapsed, active tenant context) — deliberately separate from server state to avoid the two caches fighting each other

## Directory Shape

```
frontend/src/
├── components/     # design-system primitives (Button, Card, Input, etc. — shadcn-based)
├── features/       # one folder per business domain, mirrors backend modules
│   ├── career-profile/
│   ├── skill-intelligence/
│   ├── opportunity-intelligence/
│   ├── learning-intelligence/
│   └── ai-coach/
├── routes/         # route definitions, layout shells
├── stores/         # Zustand stores
├── api/            # generated client from backend OpenAPI schema + TanStack Query hooks
└── styles/         # Tailwind config, design tokens
```

## Design System

| Token | Value | Use |
|---|---|---|
| Primary | Deep blue | Navigation, primary actions, headers |
| Accent | Teal | AI-related features, highlights, progress indicators |
| Background | Light gray | Page background |
| Surface | White | Cards, panels — subtle shadow, no heavy borders |

Style direction: professional, modern, trustworthy, and visibly "AI-enabled" without leaning on cliché sci-fi visual tropes (no glowing neon gradients) — the AI feels like a competent colleague, not a novelty.

## API Client

Generated from the backend's OpenAPI schema (FastAPI serves this at `/openapi.json` automatically) using `openapi-typescript` + a thin TanStack Query wrapper, so the frontend's request/response types can never silently drift from the backend contract — a schema change that breaks the frontend fails at generation/build time, not at runtime.

## Error Handling

The backend's consistent JSON error shape (see `security-architecture.md` / `backend-architecture.md`) is mapped to a single frontend error boundary + toast pattern, so every feature module gets consistent error UX without reimplementing it.

## Authentication Placeholder

Phase 0.2 ships a login screen wired against the Phase 1 internal JWT endpoints, with the token storage/refresh logic isolated behind a single `auth` module — so swapping in SSO/OIDC later touches one module, not every feature.
