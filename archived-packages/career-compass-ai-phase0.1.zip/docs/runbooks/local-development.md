# Runbook: Local Development Setup

## Prerequisites
- Docker + Docker Compose
- Python 3.12
- Node.js 20+ (once frontend lands in Phase 0.2)

## Backend Setup

```bash
cd backend
cp .env.example .env          # fill in local values; never commit .env
python3.12 -m venv .venv
source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Start Infrastructure Services

```bash
cd infra
docker compose up -d postgres redis minio
```

This brings up:
- **postgres** — pgvector-enabled Postgres, port 5432
- **redis** — port 6379
- **minio** — S3-compatible local object storage, ports 9000 (API) / 9001 (console)

## Run the Backend

```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

- Health check: `GET http://localhost:8000/api/v1/health`
- OpenAPI docs: `http://localhost:8000/docs`

## Run Tests

```bash
cd backend
pytest                          # all tests
pytest tests/unit                # fast, no infra required
pytest tests/integration         # requires postgres running
pytest --cov=app                 # with coverage
```

## Database Migrations

Phase 0 ships an empty Alembic baseline (no tables yet — entities begin in Phase 1).

```bash
cd backend
alembic upgrade head             # apply migrations
alembic revision -m "description"  # create a new migration (never hand-write schema)
```

## Common Issues

- **`psycopg` connection errors on start:** confirm `docker compose ps` shows `postgres` healthy before starting the backend; the container needs a few seconds after `up -d`.
- **Port conflicts:** if 5432/6379/9000 are already in use locally, override them in `infra/docker-compose.override.yml` rather than editing the base file.
- **Python version drift:** this project pins Python 3.12 intentionally (see ADR discussion in `docs/architecture/backend-architecture.md`) — 3.13/3.14 are not yet validated against all dependencies (notably database driver wheels), so use 3.12 for local development until that's revisited.
