import {
  useAddCareerGoal,
  useCareerGoals,
  useDeleteCareerGoal,
  useUpdateCareerGoal,
} from "@/api/queries/career-profile";
import type { components } from "@/api/schema.gen";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getErrorMessage } from "@/lib/errors";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";

type CareerGoal = components["schemas"]["CareerGoalResponse"];
type GoalStatus = "active" | "achieved" | "abandoned";

interface FormState {
  target_role: string;
  target_date: string;
  status: GoalStatus;
  description: string;
}

const EMPTY_FORM: FormState = {
  target_role: "",
  target_date: "",
  status: "active",
  description: "",
};

function toFormState(goal: CareerGoal): FormState {
  return {
    target_role: goal.target_role,
    target_date: goal.target_date ?? "",
    status: goal.status as GoalStatus,
    description: goal.description ?? "",
  };
}

const STATUS_VARIANT: Record<GoalStatus, "default" | "accent" | "primary"> = {
  active: "accent",
  achieved: "primary",
  abandoned: "default",
};

export function CareerGoalsSection() {
  const { data: goals, isLoading } = useCareerGoals();
  const addGoal = useAddCareerGoal();
  const updateGoal = useUpdateCareerGoal();
  const deleteGoal = useDeleteCareerGoal();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  function openAddDialog() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEditDialog(goal: CareerGoal) {
    setEditingId(goal.id);
    setForm(toFormState(goal));
    setDialogOpen(true);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (editingId) {
      updateGoal
        .mutateAsync({
          id: editingId,
          body: {
            target_role: form.target_role,
            target_date: form.target_date || null,
            status: form.status,
            description: form.description || null,
          },
        })
        .then(() => setDialogOpen(false))
        .catch(() => {});
    } else {
      addGoal
        .mutateAsync({
          target_role: form.target_role,
          target_date: form.target_date || null,
          description: form.description || null,
        })
        .then(() => setDialogOpen(false))
        .catch(() => {});
    }
  }

  const isSaving = addGoal.isPending || updateGoal.isPending;
  const saveError = addGoal.error ?? updateGoal.error;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Career Goals</CardTitle>
        <Button variant="outline" size="sm" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {goals?.length === 0 && (
          <p className="text-sm text-muted-foreground">No career goals set yet.</p>
        )}
        {goals?.map((goal) => (
          <div
            key={goal.id}
            className="flex items-start justify-between gap-4 rounded-md border border-border p-4"
          >
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{goal.target_role}</p>
                <Badge variant={STATUS_VARIANT[goal.status as GoalStatus]}>{goal.status}</Badge>
              </div>
              {goal.target_date && (
                <p className="text-xs text-muted-foreground">Target: {goal.target_date}</p>
              )}
              {goal.description && <p className="mt-1 text-sm">{goal.description}</p>}
            </div>
            <div className="flex shrink-0 gap-1">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(goal)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => deleteGoal.mutate(goal.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title={editingId ? "Edit career goal" : "Add career goal"}
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="goal-role">Target role</Label>
            <Input
              id="goal-role"
              required
              value={form.target_role}
              onChange={(e) => setForm({ ...form, target_role: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="goal-date">Target date</Label>
            <Input
              id="goal-date"
              type="date"
              value={form.target_date}
              onChange={(e) => setForm({ ...form, target_date: e.target.value })}
            />
          </div>
          {editingId && (
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="goal-status">Status</Label>
              <select
                id="goal-status"
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as GoalStatus })}
                className="h-10 rounded-md border border-border bg-card px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="active">Active</option>
                <option value="achieved">Achieved</option>
                <option value="abandoned">Abandoned</option>
              </select>
            </div>
          )}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="goal-description">Description</Label>
            <Textarea
              id="goal-description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
            />
          </div>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? "Saving..." : editingId ? "Save changes" : "Add goal"}
          </Button>
          {saveError && (
            <p role="alert" className="text-sm text-destructive">
              {getErrorMessage(saveError)}
            </p>
          )}
        </form>
      </Dialog>
    </Card>
  );
}
