import {
  useAddExperience,
  useDeleteExperience,
  useExperiences,
  useUpdateExperience,
} from "@/api/queries/career-profile";
import type { components } from "@/api/schema.gen";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getErrorMessage } from "@/lib/errors";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";

type Experience = components["schemas"]["ExperienceResponse"];

interface FormState {
  title: string;
  company: string;
  location: string;
  start_date: string;
  end_date: string;
  description: string;
}

const EMPTY_FORM: FormState = {
  title: "",
  company: "",
  location: "",
  start_date: "",
  end_date: "",
  description: "",
};

function toFormState(experience: Experience): FormState {
  return {
    title: experience.title,
    company: experience.company,
    location: experience.location ?? "",
    start_date: experience.start_date,
    end_date: experience.end_date ?? "",
    description: experience.description ?? "",
  };
}

export function ExperienceSection() {
  const { data: experiences, isLoading } = useExperiences();
  const addExperience = useAddExperience();
  const updateExperience = useUpdateExperience();
  const deleteExperience = useDeleteExperience();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  function openAddDialog() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEditDialog(experience: Experience) {
    setEditingId(experience.id);
    setForm(toFormState(experience));
    setDialogOpen(true);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = {
      title: form.title,
      company: form.company,
      location: form.location || null,
      start_date: form.start_date,
      end_date: form.end_date || null,
      description: form.description || null,
    };

    const mutation = editingId
      ? updateExperience.mutateAsync({ id: editingId, body })
      : addExperience.mutateAsync(body);

    mutation.then(() => setDialogOpen(false)).catch(() => {});
  }

  const isSaving = addExperience.isPending || updateExperience.isPending;
  const saveError = addExperience.error ?? updateExperience.error;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Experience</CardTitle>
        <Button variant="outline" size="sm" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {experiences?.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No experience added yet — add your first role to get started.
          </p>
        )}
        {experiences?.map((experience) => (
          <div
            key={experience.id}
            className="flex items-start justify-between gap-4 rounded-md border border-border p-4"
          >
            <div>
              <p className="font-medium">{experience.title}</p>
              <p className="text-sm text-muted-foreground">
                {experience.company}
                {experience.location ? ` · ${experience.location}` : ""}
              </p>
              <p className="text-xs text-muted-foreground">
                {experience.start_date} – {experience.end_date ?? "Present"}
              </p>
              {experience.description && (
                <p className="mt-2 text-sm">{experience.description}</p>
              )}
            </div>
            <div className="flex shrink-0 gap-1">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(experience)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteExperience.mutate(experience.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title={editingId ? "Edit experience" : "Add experience"}
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-title">Title</Label>
            <Input
              id="exp-title"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-company">Company</Label>
            <Input
              id="exp-company"
              required
              value={form.company}
              onChange={(e) => setForm({ ...form, company: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-location">Location</Label>
            <Input
              id="exp-location"
              value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="exp-start">Start date</Label>
              <Input
                id="exp-start"
                type="date"
                required
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="exp-end">End date</Label>
              <Input
                id="exp-end"
                type="date"
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                placeholder="Leave blank if current"
              />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-description">Description</Label>
            <Textarea
              id="exp-description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
            />
          </div>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? "Saving..." : editingId ? "Save changes" : "Add experience"}
          </Button>
          {saveError && (
            <p role="alert" className="text-sm text-destructive">
              {getErrorMessage(saveError)}
            </p>
          )}
        </form>
      </Dialog>
    </Card>
  );
}
