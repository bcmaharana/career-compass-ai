import {
  useCareerProfile,
  useUpdateCareerProfile,
  useUploadProfilePhoto,
} from "@/api/queries/career-profile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getErrorMessage } from "@/lib/errors";
import { UserCircle, X } from "lucide-react";
import { type ChangeEvent, type KeyboardEvent, useEffect, useRef, useState } from "react";

/**
 * Editable headline/photo/executive-summary/core-competencies for the
 * current user's career profile. The profile itself is created lazily
 * by the backend on first GET (see
 * app/application/career_profile/career_profile_service.py), so this
 * component never needs to handle a "no profile yet" state.
 *
 * "Executive Summary" here is the same backend field as `summary` —
 * there's no separate "About" field; the profile's `headline` already
 * serves as the short one-line version, and `summary` is the longer
 * overview, which is what "Executive Summary" refers to on the profile
 * page per the Phase 2 follow-up decision.
 */
export function ProfileHeader() {
  const { data: profile, isLoading } = useCareerProfile();
  const updateProfile = useUpdateCareerProfile();
  const uploadPhoto = useUploadProfilePhoto();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [headline, setHeadline] = useState("");
  const [summary, setSummary] = useState("");
  const [competencies, setCompetencies] = useState<string[]>([]);
  const [competencyInput, setCompetencyInput] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setHeadline(profile.headline ?? "");
      setSummary(profile.summary ?? "");
      setCompetencies(profile.core_competencies);
    }
  }, [profile]);

  function handleSave() {
    updateProfile.mutate(
      { headline: headline || null, summary: summary || null, core_competencies: competencies },
      { onSuccess: () => setIsEditing(false) },
    );
  }

  function addCompetency(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key !== "Enter" && event.key !== ",") return;
    event.preventDefault();
    const value = competencyInput.trim();
    if (value && !competencies.includes(value)) {
      setCompetencies([...competencies, value]);
    }
    setCompetencyInput("");
  }

  function removeCompetency(value: string) {
    setCompetencies(competencies.filter((c) => c !== value));
  }

  function handlePhotoChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setPhotoError(null);
    uploadPhoto.mutate(file, {
      onError: (error) => setPhotoError(getErrorMessage(error)),
    });
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">Loading profile...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Career Profile</CardTitle>
        {!isEditing && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            Edit
          </Button>
        )}
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="group relative h-16 w-16 shrink-0 overflow-hidden rounded-full border border-border bg-muted"
            aria-label="Change profile photo"
          >
            {profile?.photo_url ? (
              <img src={profile.photo_url} alt="" className="h-full w-full object-cover" />
            ) : (
              <UserCircle className="h-full w-full text-muted-foreground" strokeWidth={1} />
            )}
            <span className="absolute inset-0 flex items-center justify-center bg-black/40 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100">
              {uploadPhoto.isPending ? "Uploading..." : "Change"}
            </span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handlePhotoChange}
          />
          <div>
            <p className="font-medium">
              {profile?.headline || <span className="text-muted-foreground">No headline yet</span>}
            </p>
            {photoError && <p className="text-xs text-destructive">{photoError}</p>}
          </div>
        </div>

        {isEditing ? (
          <>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="headline">Headline / About</Label>
              <Input
                id="headline"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                placeholder="e.g. Senior Product Manager"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="summary">Executive Summary</Label>
              <Textarea
                id="summary"
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="A short overview of your professional background"
                rows={4}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="competencies">Core Competencies</Label>
              <Input
                id="competencies"
                value={competencyInput}
                onChange={(e) => setCompetencyInput(e.target.value)}
                onKeyDown={addCompetency}
                placeholder="Type a competency and press Enter"
              />
              {competencies.length > 0 && (
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {competencies.map((c) => (
                    <Badge key={c} variant="accent" className="gap-1">
                      {c}
                      <button
                        type="button"
                        onClick={() => removeCompetency(c)}
                        aria-label={`Remove ${c}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={updateProfile.isPending}>
                {updateProfile.isPending ? "Saving..." : "Save"}
              </Button>
              <Button variant="ghost" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            </div>
            {updateProfile.isError && (
              <p role="alert" className="text-sm text-destructive">
                {getErrorMessage(updateProfile.error)}
              </p>
            )}
          </>
        ) : (
          <>
            <div>
              <p className="font-display text-base font-bold text-foreground">
                Executive Summary
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {profile?.summary ||
                  "No summary yet — add one to help your AI coach get to know you."}
              </p>
            </div>
            {profile && profile.core_competencies.length > 0 && (
              <div>
                <p className="font-display text-base font-bold text-foreground">
                  Core Competencies
                </p>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {profile.core_competencies.map((c) => (
                    <Badge key={c} variant="accent">
                      {c}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
