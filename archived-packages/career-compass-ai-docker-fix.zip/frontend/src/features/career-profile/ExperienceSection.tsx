import {
  useAddExperience,
  useDeleteExperience,
  useExperiences,
  useMoveExperience,
  useUpdateExperience,
} from "@/api/queries/career-profile";
import type { components } from "@/api/schema.gen";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoveButtons } from "@/components/ui/move-buttons";
import { Textarea } from "@/components/ui/textarea";
import { formatDisplayDate } from "@/lib/date-format";
import { getErrorMessage } from "@/lib/errors";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";

type Experience = components["schemas"]["ExperienceResponse"];

interface FormState {
  title: string;
  company: string;
  location: string;
  start_date: string;
  end_date: string;
  isPresent: boolean;
  description: string;
}

const EMPTY_FORM: FormState = {
  title: "",
  company: "",
  location: "",
  start_date: "",
  end_date: "",
  isPresent: false,
  description: "",
};

function toFormState(experience: Experience): FormState {
  return {
    title: experience.title,
    company: experience.company,
    location: experience.location ?? "",
    start_date: experience.start_date,
    end_date: experience.end_date ?? "",
    isPresent: experience.end_date === null,
    description: experience.description ?? "",
  };
}

/**
 * Renders free-text description as one line per bullet — a plain <p>
 * collapses the newlines a textarea captures, making multi-point
 * descriptions read as one run-on paragraph. Splitting on newlines here
 * is display-only; the stored value keeps the user's original text
 * exactly as entered.
 */
function DescriptionBullets({ description }: { description: string | null }) {
  if (!description) return null;
  const lines = description.split("\n").filter((line) => line.trim().length > 0);
  if (lines.length <= 1) {
    return <p className="mt-2 text-sm">{description}</p>;
  }
  return (
    <ul className="mt-2 list-disc space-y-1 pl-4 text-sm">
      {lines.map((line, i) => (
        <li key={i}>{line}</li>
      ))}
    </ul>
  );
}

export function ExperienceSection() {
  const { data: experiences, isLoading } = useExperiences();
  const addExperience = useAddExperience();
  const updateExperience = useUpdateExperience();
  const deleteExperience = useDeleteExperience();
  const moveExperience = useMoveExperience();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  function openAddDialog() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEditDialog(experience: Experience) {
    setEditingId(experience.id);
    setForm(toFormState(experience));
    setDialogOpen(true);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = {
      title: form.title,
      company: form.company,
      location: form.location || null,
      start_date: form.start_date,
      end_date: form.isPresent ? null : form.end_date || null,
      description: form.description || null,
    };

    const mutation = editingId
      ? updateExperience.mutateAsync({ id: editingId, body })
      : addExperience.mutateAsync(body);

    mutation.then(() => setDialogOpen(false)).catch(() => {});
  }

  const isSaving = addExperience.isPending || updateExperience.isPending;
  const saveError = addExperience.error ?? updateExperience.error;
  const canSubmit = form.isPresent || form.end_date !== "";

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Professional Experience</CardTitle>
        <Button variant="outline" size="sm" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {experiences?.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No experience added yet — add your first role to get started.
          </p>
        )}
        {experiences?.map((experience, index) => (
          <div
            key={experience.id}
            className="flex items-start justify-between gap-4 rounded-md border border-border p-4"
          >
            <MoveButtons
              onMoveUp={() => moveExperience.mutate({ id: experience.id, direction: "up" })}
              onMoveDown={() => moveExperience.mutate({ id: experience.id, direction: "down" })}
              isFirst={index === 0}
              isLast={index === experiences.length - 1}
              disabled={moveExperience.isPending}
            />
            <div className="flex-1">
              <p className="font-medium">{experience.title}</p>
              <p className="text-sm text-muted-foreground">
                {experience.company}
                {experience.location ? ` · ${experience.location}` : ""}
              </p>
              <p className="text-xs text-muted-foreground">
                {formatDisplayDate(experience.start_date)} –{" "}
                {experience.end_date ? formatDisplayDate(experience.end_date) : "Present"}
              </p>
              <DescriptionBullets description={experience.description} />
            </div>
            <div className="flex shrink-0 gap-1">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(experience)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteExperience.mutate(experience.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title={editingId ? "Edit experience" : "Add experience"}
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-title">Title</Label>
            <Input
              id="exp-title"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-company">Company</Label>
            <Input
              id="exp-company"
              required
              value={form.company}
              onChange={(e) => setForm({ ...form, company: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-location">Location</Label>
            <Input
              id="exp-location"
              value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="exp-start">Start date</Label>
              <Input
                id="exp-start"
                type="date"
                required
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="exp-end">
                End date {!form.isPresent && <span className="text-destructive">*</span>}
              </Label>
              <Input
                id="exp-end"
                type="date"
                required={!form.isPresent}
                disabled={form.isPresent}
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.isPresent}
              onChange={(e) =>
                setForm({ ...form, isPresent: e.target.checked, end_date: "" })
              }
              className="h-4 w-4 rounded border-border"
            />
            I currently work here
          </label>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="exp-description">Description</Label>
            <Textarea
              id="exp-description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
              placeholder="One point per line — each renders as its own bullet"
            />
          </div>
          <Button type="submit" disabled={isSaving || !canSubmit}>
            {isSaving ? "Saving..." : editingId ? "Save changes" : "Add experience"}
          </Button>
          {saveError && (
            <p role="alert" className="text-sm text-destructive">
              {getErrorMessage(saveError)}
            </p>
          )}
        </form>
      </Dialog>
    </Card>
  );
}
