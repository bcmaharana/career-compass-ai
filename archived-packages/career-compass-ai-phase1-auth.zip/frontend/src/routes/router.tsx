import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/features/dashboard/DashboardPage";
import { LoginPage } from "@/features/auth/LoginPage";
import { NotFoundPage } from "@/routes/NotFound";
import { ProtectedRoute } from "@/routes/ProtectedRoute";
import { createBrowserRouter } from "react-router-dom";

/**
 * Route tree. Feature modules add their own routes here as they land
 * (Phase 2 onward) — this file stays the single source of truth for the
 * app's URL structure, rather than routes being registered ad hoc from
 * inside feature components.
 *
 * /login is outside ProtectedRoute (it IS the escape hatch for
 * unauthenticated visitors). Everything under AppShell requires a
 * session — see routes/ProtectedRoute.tsx.
 */
export const router = createBrowserRouter([
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    element: <ProtectedRoute />,
    children: [
      {
        path: "/",
        element: <AppShell />,
        children: [
          { index: true, element: <DashboardPage /> },
          // /skills and /coach nav links exist in AppShell already;
          // their route elements arrive with Phase 3 and Phase 8 respectively.
        ],
      },
    ],
  },
  {
    path: "*",
    element: <NotFoundPage />,
  },
]);
